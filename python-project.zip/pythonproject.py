import bcrypt
class PasswordDatabase:
  def __init__(self):
    self.data = dict()
  def register(self, user, password):
    if user in self.data:
      return False
    pwd_hash = self.hash_password(password)
    self.data[user] = pwd_hash
    return True
  def login(self, user, password):
    if user not in self.data:
      return False
    pwd_bytes = password.encode("utf-8")
    return bcrypt.checkpw(pwd_bytes, self.data[user])
  def hash_password(self, password):
    pwd_bytes = password.encode("utf-8")
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(pwd_bytes, salt)

db = PasswordDatabase()

print("User Registration in process"),
print(db.register("mahi", "password")),
print(db.register("niyaz", "HelloWorld")),
print(db.register("nisa", "myname"))

print("Please login")
user = input("Enter your username: ") 
password = input("Enter your password: ")
print(db.login(user, password))



#Written commands to execute multifactor authentication(one time password to verify
#the identify of the authentic users.
#import math, random

# import library
import pyotp

totp = pyotp.TOTP("base32secret3232")
print("Your OTP is ", totp.now())

if totp.verify("174129") == True:
    print("Successful Login")
else:
    print("Unsuccessful")



